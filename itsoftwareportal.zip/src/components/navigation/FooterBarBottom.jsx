
const FooterBarBottom = () => {
  return (
    <>
        <footer className="main-footer-bar">
            <div className="copyright-bar">
                <a href="#">bimcap.com</a>
            </div>
        </footer>
    </>
  )
}

export default FooterBarBottom