
const LoginFooterBarBottom = () => {
  return (
    <>
        <footer className="main-footer-bar-login">
            <div className="copyright-bar">
                <a href="#">bimcap.com</a>
            </div>
        </footer>
    </>
  )
}

export default LoginFooterBarBottom